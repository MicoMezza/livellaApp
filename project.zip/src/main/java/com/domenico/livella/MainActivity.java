package com.domenico.livella;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebChromeClient;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.content.Context;
public class MainActivity extends Activity implements SensorEventListener {
    WebView webView; SensorManager sm; Sensor acc; float sx=0,sy=0;
    protected void onCreate(Bundle b){
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        webView=findViewById(R.id.webview);
        WebSettings ws=webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowUniversalAccessFromFileURLs(true);
        ws.setAllowFileAccessFromFileURLs(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("file:///android_asset/livella.html");
        sm=(SensorManager)getSystemService(Context.SENSOR_SERVICE);
        acc=sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
    }
    protected void onResume(){ super.onResume(); if(acc!=null) sm.registerListener(this,acc,SensorManager.SENSOR_DELAY_FASTEST); }
    protected void onPause(){ super.onPause(); sm.unregisterListener(this); }
    public void onSensorChanged(SensorEvent e){
        float ax=e.values[0], ay=e.values[1], az=e.values[2];
        double angX=Math.toDegrees(Math.atan2(ax,az)), angY=Math.toDegrees(Math.atan2(ay,az));
        sx=sx*0.2f+(float)angX*0.8f; sy=sy*0.2f+(float)angY*0.8f;
        String js=String.format("javascript:if(window.setNativeSensor){window.setNativeSensor(%f,%f)}",sx,sy);
        runOnUiThread(()->webView.evaluateJavascript(js,null));
    }
    public void onAccuracyChanged(Sensor s,int a){}
}
