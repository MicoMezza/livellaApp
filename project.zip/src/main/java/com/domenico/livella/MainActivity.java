package com.domenico.livella;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebChromeClient;
import android.webkit.WebViewClient;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.content.Context;
import android.widget.FrameLayout;
import android.view.ViewGroup;

public class MainActivity extends Activity implements SensorEventListener {
    WebView webView;
    SensorManager sm;
    Sensor acc;
    float sx=0,sy=0;
    boolean webReady=false;

    protected void onCreate(Bundle b){
        super.onCreate(b);
        try {
            // Prova a creare WebView programmaticamente - mai crash
            webView = new WebView(this);
            webView.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            FrameLayout root = new FrameLayout(this);
            root.addView(webView);
            setContentView(root);
        } catch (Exception e) {
            // Se anche questo fallisce, esci pulito
            e.printStackTrace();
            finish();
            return;
        }

        try {
            WebSettings ws = webView.getSettings();
            ws.setJavaScriptEnabled(true);
            ws.setDomStorageEnabled(true);
            ws.setAllowFileAccess(true);
            ws.setAllowUniversalAccessFromFileURLs(true);
            ws.setAllowFileAccessFromFileURLs(true);
            ws.setJavaScriptCanOpenWindowsAutomatically(true);
            webView.setWebChromeClient(new WebChromeClient());
            webView.setWebViewClient(new WebViewClient() {
                public void onPageFinished(WebView view, String url) {
                    webReady = true;
                }
            });
            webView.loadUrl("file:///android_asset/livella.html");
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            sm = (SensorManager)getSystemService(Context.SENSOR_SERVICE);
            if(sm!=null) acc = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected void onResume(){
        super.onResume();
        try {
            if(sm!=null && acc!=null) sm.registerListener(this, acc, SensorManager.SENSOR_DELAY_GAME);
        } catch (Exception e) { e.printStackTrace(); }
    }

    protected void onPause(){
        super.onPause();
        try { if(sm!=null) sm.unregisterListener(this); } catch (Exception e) { e.printStackTrace(); }
    }

    public void onSensorChanged(SensorEvent e){
        if(!webReady || webView==null) return;
        try {
            float ax=e.values[0], ay=e.values[1], az=e.values[2];
            double angX=Math.toDegrees(Math.atan2(ax,az));
            double angY=Math.toDegrees(Math.atan2(ay,az));
            sx=sx*0.2f+(float)angX*0.8f;
            sy=sy*0.2f+(float)angY*0.8f;
            final String js = String.format("javascript:if(window.setNativeSensor){window.setNativeSensor(%f,%f)}", sx, sy);
            runOnUiThread(new Runnable() {
                public void run() {
                    try { webView.evaluateJavascript(js, null); } catch (Exception ex) { ex.printStackTrace(); }
                }
            });
        } catch (Exception ex) { ex.printStackTrace(); }
    }
    public void onAccuracyChanged(Sensor s,int a){}
}
